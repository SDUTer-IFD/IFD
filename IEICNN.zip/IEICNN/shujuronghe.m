% Multi-Signals-to-RGB-Image for kat dataset 

clc;clear;close; % Release all data
%load dongnandaxuezhoucheng;
%load dongnandaxue;
load �ȼ�5�ȼ�5;
data=[nor];
%data=[of1;of2];
%data=[bf;bf1;bf2;bf3];
%data=[hf;hf1;hf2;hf3];
%data=[If;If1;If2;If3];
%data=[n;n1;n2;n3];
%data=[of;of1;of2;of3];
%data=[bf;hf;If;n;of];
%addpath(genpath(pwd)); % Add all files to working path
%--------------------------------------------------------------------------
% Initialization Parameters
%--------------------------------------------------------------------------
Samples =200; 
ImageL = 32; ImageW = ImageL; ImageSize = ImageL * ImageW;
dataPoints = ImageSize; % points from signals
signal_cut_1 = zeros(Samples,ImageSize);
signal_cut_2 = zeros(Samples,ImageSize);
signal_cut_3 = zeros(Samples,ImageSize);
%OPERATING = ["N15_M07_F10","N09_M07_F10","N15_M01_F10","N15_M07_F04"];
%operate_name = ["IF0.2"]
%FILES = ["Healthy", "Outer", "Inner"];  % healthy, outer ring fault, inner ring fault
%output_dir = strcat("out/Kat_",num2str(ImageL),"_pcaRGB/");
%data_dir = "dataset/KAT/";
%data_dir = "";
%load A1;
%data=A1
 %Random Sampling, Cut and normalize signal
%if save_flag==true
randomSerial = round(unifrnd (0, 1, 1, Samples)*((length(data)-dataPoints)));%unifrnd �������������
   for iCut=1:Samples
  cutIndex = randomSerial(iCut);
  signalCut1(iCut,:) = normalize255(data((cutIndex+1):(cutIndex+dataPoints),1));
  signalCut2(iCut,:) = normalize255(data((cutIndex+1):(cutIndex+dataPoints),2));
  signalCut3(iCut,:) = normalize255(data((cutIndex+1):(cutIndex+dataPoints),3));
   end
%----------------------------------------------------------------------
%  Convert signal to images
%----------------------------------------------------------------------
 for iImage=1:Samples
 imgPre1 = signalCut1(iImage,:);
 imgPre2 = signalCut2(iImage,:);
 imgPre3 = signalCut3(iImage,:);
 img1 = reshape(imgPre1,sqrt(dataPoints),sqrt(dataPoints));
 img2 = reshape(imgPre2,sqrt(dataPoints),sqrt(dataPoints));
 img3 = reshape(imgPre3,sqrt(dataPoints),sqrt(dataPoints));
 imgRGB = cat(3,img1,img2,img3);%cat��ָ��ά�ȴ�������
 a=uint8(imgRGB)
 %imwrite(a,strcat(num2str(Samples),'-0.jpeg'));
 %imwrite(a,strcat('C:\Users\guocai\Desktop\����\�Ϻ�\ÿ������400������\nanhang1500100\ԭʼ\4\',num2str(iImage),'-4.jpg'));
 %imwrite(a,strcat('C:\Users\guocai\Desktop\����\���ϴ�ѧ\ÿ������200������\���ϴ�ѧ30-2\ԭʼ\4\',num2str(iImage),'-4.jpg'));
 %imwrite(a,strcat('C:\Users\guocai\Desktop\����\ʱ��ת��\�Ϻ�\�ȼ����ȼ���\ԭʼ\4\',num2str(iImage),'-4.jpg'));
 imwrite(a,strcat('D:\����\ɽ��\ʱ��ת��\�ȼ�5�ȼ�5\1\',num2str(iImage),'-1.jpg'));
 %imwrite(a,strcat('out\Kat_64_pcaRGB\1\class5\',num2str(iImage),'-4.jpg'));
 end