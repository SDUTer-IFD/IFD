*************************************************************************************************************************************************************************
This package contains the source code and dataset used in the following paper:

"Guocai Nie, Zhongwei Zhang, Zonghao Jiao, Youjia Li, Mingyu Shao, Xiangjun Dai. A novel intelligent bearing fault diagnosis method based on image enhancement and improved convolutional neural network, 2024."


Usage of this code is only free for research purposes. Please refer to the above publication if you use this code. 

This demo is implemented by Guocai Nie (ngc991@163.com).
*************************************************************************************************************************************************************************

Usage:

Main.m ----- Implementation of the Improved convolutional neural network.